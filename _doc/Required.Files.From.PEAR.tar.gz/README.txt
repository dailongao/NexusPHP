PEAR Package Required For NexusPHP 1.5 beta 4
These files are from PEAR project (http://pear.php.net) that are required to enable the feature of IMDb information scraping of NexusPHP.
It is recommended to install PEAR packages with the PEAR installer (available on both *nix and Windows) by the following steps:
1.Install PEAR commandline tool:
*nix: use the package manager provided by your OS. For ubuntu 10.04, run this command:
sudo apt-get install php-pear
Windows: run the batch file named 'go-pear.bat' bundled with your PHP installation.
2.As I am writing, the package HTTP_Request2 is in the state of 'alpha'. To install it, you need to change your preferred state of PEAR packages to 'alpha' using the following command:
pear config-set preferred_state alpha
3.Install required packages:
pear install HTTP_Request2

However, if you don't have the privilege to install new packages on your server, you could include files from PEAR packages manually. Just put all files from this package into the root directory of codes of NexusPHP.

Written by Xia Zuojie
2010-05-08
